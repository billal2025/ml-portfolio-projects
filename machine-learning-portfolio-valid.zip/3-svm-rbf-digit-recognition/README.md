# 3 Svm Rbf Digit Recognition

Project description goes here.