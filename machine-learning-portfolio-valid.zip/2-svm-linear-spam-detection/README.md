# 2 Svm Linear Spam Detection

Project description goes here.