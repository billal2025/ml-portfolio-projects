# Machine Learning Portfolio

This repo includes classification projects using Logistic Regression, SVM, Decision Tree, and KNN.